#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libpq-fe.h>
#include <dirent.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define MIGRATIONS_DIR "/app/migrations"
#define BUFFER_SIZE 4096

PGconn *connect_to_db() {
    const char *conninfo = "host=db port=5432 dbname=mydatabase user=user password=password";
    PGconn *conn = PQconnectdb(conninfo);

    if (PQstatus(conn) != CONNECTION_OK) {
        fprintf(stderr, "Connection to database failed: %s", PQerrorMessage(conn));
        PQfinish(conn);
        exit(1);
    }

    return conn;
}

void run_migrations(PGconn *conn) {
    PGresult *res = PQexec(conn, 
        "SELECT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'migrations');");
    
    if (PQresultStatus(res) != PGRES_TUPLES_OK) {
        fprintf(stderr, "Error checking migrations table: %s\n", PQerrorMessage(conn));
        PQclear(res);
        exit(1);
    }

    if (strcmp(PQgetvalue(res, 0, 0), "t") != 0) {
        PQclear(res);
        res = PQexec(conn, 
            "CREATE TABLE migrations ("
            "id SERIAL PRIMARY KEY,"
            "name VARCHAR(255) NOT NULL UNIQUE,"
            "applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
            ");");
        
        if (PQresultStatus(res) != PGRES_COMMAND_OK) {
            fprintf(stderr, "Error creating migrations table: %s\n", PQerrorMessage(conn));
            PQclear(res);
            exit(1);
        }
    }
    PQclear(res);

    DIR *dir = opendir(MIGRATIONS_DIR);
    if (!dir) {
        perror("Failed to open migrations directory");
        exit(1);
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type != DT_REG) continue;

        char query[512];
        snprintf(query, sizeof(query), 
                "SELECT 1 FROM migrations WHERE name = '%s'", entry->d_name);
        res = PQexec(conn, query);
        
        if (PQntuples(res) == 0) {
            printf("Applying migration: %s\n", entry->d_name);
            
            char path[512];
            snprintf(path, sizeof(path), "%s/%s", MIGRATIONS_DIR, entry->d_name);
            
            FILE *file = fopen(path, "r");
            if (!file) {
                perror("Failed to open migration file");
                exit(1);
            }
            
            fseek(file, 0, SEEK_END);
            long size = ftell(file);
            fseek(file, 0, SEEK_SET);
            
            char *sql = malloc(size + 1);
            fread(sql, 1, size, file);
            sql[size] = '\0';
            fclose(file);
            
            PGresult *mig_res = PQexec(conn, sql);
            if (PQresultStatus(mig_res) != PGRES_COMMAND_OK) {
                fprintf(stderr, "Migration failed: %s\n", PQerrorMessage(conn));
                PQclear(mig_res);
                exit(1);
            }
            PQclear(mig_res);
            
            snprintf(query, sizeof(query),
                    "INSERT INTO migrations (name) VALUES ('%s')", entry->d_name);
            mig_res = PQexec(conn, query);
            if (PQresultStatus(mig_res) != PGRES_COMMAND_OK) {
                fprintf(stderr, "Failed to log migration: %s\n", PQerrorMessage(conn));
            }
            PQclear(mig_res);
            free(sql);
        }
        PQclear(res);
    }
    closedir(dir);
}

void create_table(PGconn *conn) {
    const char *sql = "CREATE TABLE IF NOT EXISTS users (id SERIAL PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL);";
    PGresult *res = PQexec(conn, sql);

    if (PQresultStatus(res) != PGRES_COMMAND_OK) {
        fprintf(stderr, "CREATE TABLE failed: %s", PQerrorMessage(conn));
        PQclear(res);
        PQfinish(conn);
        exit(1);
    }

    PQclear(res);
}

void escape_sql_string(char *dest, const char *src, size_t max_len) {
    size_t i, j;
    for (i = 0, j = 0; src[i] != '\0' && j < max_len - 1; i++) {
        if (src[i] == '\'') {
            if (j < max_len - 2) {
                dest[j++] = '\'';
                dest[j++] = '\'';
            }
        } else {
            dest[j++] = src[i];
        }
    }
    dest[j] = '\0';
}

void handle_request(PGconn *conn, const char *method, const char *path, const char *body, char *response, size_t response_size) {
    response[0] = '\0';

    if (strcmp(path, "/users") == 0) {
        if (strcmp(method, "GET") == 0) {
            PGresult *res = PQexec(conn, "SELECT id, name, email, created_at FROM users;");
if (PQresultStatus(res) == PGRES_TUPLES_OK) {
    int rows = PQntuples(res);
    snprintf(response, response_size, "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n[");
    for (int i = 0; i < rows; i++) {
        char record[512];
        snprintf(record, sizeof(record), 
            "%s{\"id\":%s,\"name\":\"%s\",\"email\":\"%s\",\"created_at\":\"%s\"}",
            (i > 0) ? "," : "",
            PQgetvalue(res, i, 0),
            PQgetvalue(res, i, 1),
            PQgetvalue(res, i, 2),
            PQgetvalue(res, i, 3));
        strncat(response, record, response_size - strlen(response) - 1);
    }
    strncat(response, "]", response_size - strlen(response) - 1);
} else {
                snprintf(response, response_size, "HTTP/1.1 500 Internal Server Error\r\n\r\nDatabase error");
            }
            PQclear(res);
            
        } else if (strcmp(method, "PUT") == 0) {
            char *name_start = strstr(body, "\"name\":\"");
            char *email_start = strstr(body, "\"email\":\"");
            
            if (name_start && email_start) {
                name_start += 8;
                char *name_end = strchr(name_start, '"');
                email_start += 9;
                char *email_end = strchr(email_start, '"');
                
                if (name_end && email_end) {
                    *name_end = '\0';
                    *email_end = '\0';
                    
                    // Экранирование строк для SQL
                    char safe_name[256], safe_email[256];
                    escape_sql_string(safe_name, name_start, sizeof(safe_name));
                    escape_sql_string(safe_email, email_start, sizeof(safe_email));
                    
                    char sql[512];
                    snprintf(sql, sizeof(sql), 
                            "INSERT INTO users (name, email) VALUES ('%s', '%s') RETURNING id;",
                            safe_name, safe_email);
                    
                    PGresult *res = PQexec(conn, sql);
                    
                    if (PQresultStatus(res) == PGRES_TUPLES_OK) {
                        snprintf(response, response_size, 
                                "HTTP/1.1 201 Created\r\nContent-Type: application/json\r\n\r\n"
                                "{\"id\":%s,\"name\":\"%s\",\"email\":\"%s\"}",
                                PQgetvalue(res, 0, 0), name_start, email_start);
                    } else {
                        snprintf(response, response_size, 
                                "HTTP/1.1 400 Bad Request\r\n\r\nDatabase error: %s", 
                                PQerrorMessage(conn));
                    }
                    PQclear(res);
                } else {
                    snprintf(response, response_size, 
                            "HTTP/1.1 400 Bad Request\r\n\r\nInvalid JSON format");
                }
            } else {
                snprintf(response, response_size, 
                        "HTTP/1.1 400 Bad Request\r\n\r\nMissing name or email in JSON");
            }
        }
    } else if (strstr(path, "/users/") != NULL) {
        int id = atoi(path + 7);

        if (strcmp(method, "GET") == 0) {
            char sql[256];
            snprintf(sql, sizeof(sql), "SELECT id, name, email FROM users WHERE id = %d;", id);
            PGresult *res = PQexec(conn, sql);

            if (PQresultStatus(res) == PGRES_TUPLES_OK) {
                if (PQntuples(res) > 0) {
                    snprintf(response, response_size,
                            "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"
                            "{\"id\":%s,\"name\":\"%s\",\"email\":\"%s\"}",
                            PQgetvalue(res, 0, 0),
                            PQgetvalue(res, 0, 1),
                            PQgetvalue(res, 0, 2));
                } else {
                    snprintf(response, response_size, "HTTP/1.1 404 Not Found\r\n\r\nUser not found");
                }
            } else {
                snprintf(response, response_size, "HTTP/1.1 500 Internal Server Error\r\n\r\nDatabase error");
            }
            PQclear(res);
        } else if (strcmp(method, "DELETE") == 0) {
            char sql[256];
            snprintf(sql, sizeof(sql), "DELETE FROM users WHERE id = %d RETURNING id;", id);
            PGresult *res = PQexec(conn, sql);

            if (PQresultStatus(res) == PGRES_TUPLES_OK) {
                if (PQntuples(res) > 0) {
                    snprintf(response, response_size,
                            "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"
                            "{\"message\":\"User deleted\",\"id\":%s}",
                            PQgetvalue(res, 0, 0));
                } else {
                    snprintf(response, response_size, "HTTP/1.1 404 Not Found\r\n\r\nUser not found");
                }
            } else {
                snprintf(response, response_size, "HTTP/1.1 500 Internal Server Error\r\n\r\nDatabase error");
            }
            PQclear(res);
        }
    } else {
        snprintf(response, response_size, "HTTP/1.1 404 Not Found\r\n\r\nNot Found");
    }
}

void start_server(PGconn *conn) {
    int server_fd, new_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    char buffer[BUFFER_SIZE] = {0};
    char response[BUFFER_SIZE] = {0};
    
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }
    
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }
    
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);
    
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
    
    if (listen(server_fd, 10) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }
    
    printf("Server started on port %d\n", PORT);
    
    while (1) {
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {
            perror("accept");
            continue;
        }
        
        ssize_t bytes_read = read(new_socket, buffer, BUFFER_SIZE);
        if (bytes_read > 0) {
            char method[16], path[256];
            sscanf(buffer, "%s %s", method, path);
            
            handle_request(conn, method, path, buffer, response, sizeof(response));
            write(new_socket, response, strlen(response));
        }
        
        close(new_socket);
        memset(buffer, 0, BUFFER_SIZE);
    }
}

int main() {
    PGconn *conn = connect_to_db();
    create_table(conn);
    run_migrations(conn);
    start_server(conn);
    PQfinish(conn);
    return 0;
}