#!/bin/sh

./driver ./examples/good.cl
