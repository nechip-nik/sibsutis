#!/bin/sh

./driver ./prog2.cl
